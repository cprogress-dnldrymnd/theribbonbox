<?php 
the_content();?>
<div class="loadingnextOuter">
    <h1>B2B homepage</h1>
    <a id="loadHome"></a>
</div>

<?php //WPBMap::addAllMappedShortcodes(); ?>
<?php include 'js/home-js.php'; ?>