<!-- index-error-not-found.php -->
<div class="page-content">
    <h1>Oops!</h1>
    <p>404. We can't seem to find the page you're looking for.</p>
</div>