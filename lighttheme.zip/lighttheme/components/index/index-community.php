<?php
echo "<!-- index-community.php -->";
echo '
<div class="quiz-outer-out community-outer-out" id="community-outer-out">
    <div class="quiz-outer">
        <div class="quiz-inner">
            <div class="quiz-inner-in-out-out">
                <div class="quiz-inner-in-out">
                    <h2>Coming Soon</h2><hr>
                    <p>'."Lovely to see you! We're busy getting this community space ready for launch. Subscribe to be the first in and let us know which chat topics are important to you.<br><br><strong>THE RIBBON BOX</strong>".'</p>
                 
                    <div class="quiz-inner-in">'; echo do_shortcode('[mc-subscribe-form]'); echo '</div>
                </div>
            </div>
        </div>
    </div>
</div>';