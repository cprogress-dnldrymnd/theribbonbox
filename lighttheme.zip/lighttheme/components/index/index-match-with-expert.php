<?php
echo "<!-- index-match-with-expert.php -->";

echo '<div class="blog-top-ban blog-top-ban-podcast blog-top-ban-match"><div class="blog-top-ban-podcast-inner"><div class="blog-l-text-out" style="border-top: 5px solid #034146;"><div class="blog-l-text"><h2>Not sure which expert is right for you?</h2><p>Take our quiz for personalised recommendations on experts. It takes a few minutes and we will get back to you shortly.</p><h3>Match with an expert by taking our quiz below.</h3></div></div><div class="blog-l-img" style="background:url(/wp-content/themes/lighttheme/images/matchwithexpert-header.jpg); background-size:cover; background-position:center;"><img src="/wp-content/themes/lighttheme/images/vid_req.png"></div></div></div>';


echo do_shortcode('[match_expert_form]');
