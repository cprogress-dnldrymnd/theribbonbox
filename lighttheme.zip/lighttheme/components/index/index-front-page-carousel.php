<!-- index-front-page-carousel.php -->
<link rel="stylesheet" href="/wp-content/themes/lighttheme/stylesheet/slick.css">
<link rel="stylesheet" href="/wp-content/themes/lighttheme/stylesheet/slick-theme.css">
<script src="/wp-content/themes/lighttheme/js/slick.js"></script>

<script type="text/javascript">
    <?php include get_template_directory() . '/js/woocommerce-products-carousel.js'; ?>
</script>