<?php
echo "<!-- index-thanks-quiz.php -->";

echo '<div id="quiz-outer-out" class="quiz-outer-out">
        <div class="quiz-bg"></div>
        <div class="quiz-outer">
        <div class="quiz-inner">
        <div class="quiz-inner-in-out-out">
        <div class="quiz-inner-in-out">
        <div class="quiz-inner-in">
        <div>
        <div class="fm-form-container fm-theme1">
        <div id="fm-pages10" class="fm-pages wdform_page_navigation "></div>
        <form id="form10" class="fm-form form10 fm-form-submitted" action="/experts/match-with-an-expert/?succes=1677255431" enctype="multipart/form-data" method="post" name="form10">
        <div class="fm-message ">
        <h3 style="text-align: center !important;">Thanks for taking our quiz!</h3>
        <p style="text-align: center !important;">';
echo "Save hello@theribbonbox.com to your safe-senders list so help doesn't end up in your junk folder.</p></div></form></div></div></div></div></div></div></div></div>";