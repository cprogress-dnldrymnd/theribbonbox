<textarea cols='40' rows='5' name='pw_settings[pw_textarea_intro]'>
    <?php echo isset( $options['pw_textarea_intro'] ) ?  $options['pw_textarea_intro'] : false; ?>
</textarea>